//
//  TrackRenderer.swift
//  WorldRoad
//
//  Created by norains on 2021/04/25.
//  Copyright © 2019 norains. All rights reserved.
//

import MapKit
import UIKit

class TrackRenderer {
    private(set) var mapView: MKMapView?
    private(set) var mode = Mode.clear
    
    enum Mode: Int, CaseIterable, Codable {
        case clear
        case fog

        var localizedDescription: String {
            switch self {
            case .clear:
                return NSLocalizedString("Clear", comment: "")
            case .fog:
                return NSLocalizedString("Fog", comment: "")
            }
        }
    }

    @discardableResult func open(mapView: MKMapView) -> Bool {
        self.mapView = mapView
        return true
    }

    func close() {
    }

    func switchMode(mode: Mode) -> Bool {
        self.mode = mode
        return true
    }

    var MKPolylineRenderer: MKPolylineRenderer? {
        return nil
    }

    var CALayer: CALayer? {
        return nil
    }

    func updateDynamicTrack(coordinates: [CLLocationCoordinate2D]) {
    }

    typealias StaticTrackID = Int
    func addStaticTrackTrack(coordinates: [CLLocationCoordinate2D]) -> StaticTrackID {
        return 0
    }

    func removeStaticTrack(staticTrackID: StaticTrackID) {
    }

    func removeAllStaticTrack() {
    }
}
