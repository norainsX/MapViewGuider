//
//  MapViewTrackRenderer.swift
//  WorldRoad
//
//  Created by norains on 2021/04/25.
//  Copyright © 2019 norains. All rights reserved.
//

import MapKit
import UIKit

class MapViewTrackRenderer {
    private var trackRenderer: TrackRenderer
    private var mapView: MKMapView

    enum Renderer: Int {
        case polyline
        case layer
    }

    private var renderer: Renderer

    var mkPolylineRenderer: MKPolylineRenderer? {
        return trackRenderer.MKPolylineRenderer
    }

    init(mapView: MKMapView, renderer: Renderer) {
        trackRenderer = MapViewTrackRenderer.getTrackRender(renderer: renderer)
        self.renderer = renderer
        self.mapView = mapView

        trackRenderer.open(mapView: mapView)
    }

    func switchRenderer(renderer: Renderer) {
        if self.renderer == renderer {
            // Do nothing
            return
        }

        self.renderer = renderer

        trackRenderer.close()
        trackRenderer = MapViewTrackRenderer.getTrackRender(renderer: renderer)
        trackRenderer.open(mapView: mapView)
    }

    func switchMode(mode: TrackRenderer.Mode) -> Bool {
        return trackRenderer.switchMode(mode: mode)
    }

    private static func getTrackRender(renderer: Renderer) -> TrackRenderer {
        if renderer == .layer {
            return LayerRenderer()
        } else {
            return PolylineRenderer()
        }
    }
    
    func updateDynamicTrack(coordinates: [CLLocationCoordinate2D]) {
        trackRenderer.updateDynamicTrack(coordinates: coordinates)
    }

    func addStaticTrackTrack(coordinates: [CLLocationCoordinate2D]) -> TrackRenderer.StaticTrackID {
        return trackRenderer.addStaticTrackTrack(coordinates: coordinates)
    }

    func removeStaticTrack(staticTrackID: TrackRenderer.StaticTrackID) {
        trackRenderer.removeStaticTrack(staticTrackID: staticTrackID)
    }

    func removeAllStaticTrack() {
        trackRenderer.removeAllStaticTrack()
    }
}
