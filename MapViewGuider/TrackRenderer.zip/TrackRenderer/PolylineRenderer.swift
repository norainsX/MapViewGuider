//
//  PolylineRenderer.swift
//  WorldRoad
//
//  Created by norains on 2021/04/25.
//  Copyright © 2019 norains. All rights reserved.
//
import MapKit

class PolylineRenderer: TrackRenderer {
    private var dynamicTrackPolyline: MKPolyline?
    private var mkPolylineRenderer = _MKPolylineRenderer()
    private var staticPolylines = [StaticTrackID: MKPolyline]()

    override var MKPolylineRenderer: MKPolylineRenderer? {
        return mkPolylineRenderer
    }

    override func switchMode(mode: Mode) -> Bool {
        if mode == .fog {
            print("[Error]PolylineRenderer does not support fog mode!")
            return false
        }

        return super.switchMode(mode: mode)
    }

    override func updateDynamicTrack(coordinates: [CLLocationCoordinate2D]) {
        if let mapView = self.mapView {
            // Add the new polyline
            let newPolyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
            mapView.addOverlay(newPolyline)

            // Remove the old polyline if need
            if let dynamicTrackPolyline = self.dynamicTrackPolyline {
                mapView.removeOverlay(dynamicTrackPolyline)
            }

            dynamicTrackPolyline = newPolyline
        }
    }

    private var newStaticTrackID: StaticTrackID {
        if staticPolylines.count == 0 {
            return 0
        } else {
            var id: StaticTrackID = 0
            while true {
                if staticPolylines.keys.contains(id) == false {
                    return id
                }

                id += 1
            }
        }
    }

    override func addStaticTrackTrack(coordinates: [CLLocationCoordinate2D]) -> StaticTrackID {
        if let mapView = self.mapView {
            let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
            mapView.addOverlay(polyline)

            let newStaticTrackID = self.newStaticTrackID
            staticPolylines[newStaticTrackID] = polyline

            return newStaticTrackID
        }

        return 0
    }

    override func removeStaticTrack(staticTrackID: StaticTrackID) {
        if let mapView = self.mapView, let polyline = staticPolylines[staticTrackID] {
            mapView.removeOverlay(polyline)
            staticPolylines[staticTrackID] = nil
        }
    }

    override func removeAllStaticTrack() {
        for (_, polyline) in staticPolylines {
            mapView?.removeOverlay(polyline)
        }

        staticPolylines.removeAll()
    }
}

fileprivate class _MKPolylineRenderer: MKPolylineRenderer {
    override func draw(_ mapRect: MKMapRect, zoomScale: MKZoomScale, in context: CGContext) {
        // 线条的颜色
        strokeColor = UIColor.red
        // 线条的大小
        lineWidth = 5
        super.draw(mapRect, zoomScale: zoomScale, in: context)
    }
}
